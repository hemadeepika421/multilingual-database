from django.apps import AppConfig


class CitationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'citation'
